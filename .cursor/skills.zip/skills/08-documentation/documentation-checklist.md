# Documentation Checklist — Phase 08

Complete this checklist before presenting the documentation gate. All No-Go items must pass.

---

## No-Go (hard stop if any fails)

- [ ] **Artifact index exists** — Lists every artifact from Phases 1–6
- [ ] **Artifact paths resolvable** — All paths/URLs in the index are valid and accessible
- [ ] **User documentation exists** — Quick Start + at least one Feature Guide
- [ ] **Ops runbook product-specific** — Rollback steps, incident response, release process adapted for this product
- [ ] **Stakeholder package exists** — Executive summary, what was delivered, success metrics, next steps
- [ ] **Entry point exists** — `docs/README.md` or equivalent links to all documentation

---

## Quality (should pass — can proceed with documented exceptions)

- [ ] **FAQ** — At least 5 entries
- [ ] **Last updated dates** — All docs have a "Last updated: [Date]" line
- [ ] **No orphan docs** — Every doc is linked from README or artifact index
- [ ] **Writing guide followed** — Clarity, simplicity, scannability (see [writing-guide.md](writing-guide.md))

---

## Artifact Index Verification

| Phase | Expected Artifacts | Verified |
|-------|--------------------|----------|
| 1. Discovery | PRD, Personas, Journey Map, Competitive Analysis, Stakeholder Brief, Problem Statement | [ ] |
| 2. Product Design | IA, User Flows, Wireframes, Interaction Spec, Prototype Brief | [ ] |
| 3. Frontend Design | Design tokens, Figma/Manifest or BOM + Screen Specs | [ ] |
| 4. Frontend Dev | Working app, Architecture, FAI report, Test Coverage Matrix | [ ] |
| 5. QA Testing | Test suite, Coverage Matrix, Audit reports | [ ] |
| 6. Deployment | Production URL, Release notes, Ops runbook, Launch checklist | [ ] |

---

## User Documentation Verification

- [ ] Quick Start: 3–5 steps to first value
- [ ] Feature Guide: At least one section per P0 feature
- [ ] Plain language; no jargon
- [ ] Scannable headings

---

## Ops Documentation Verification

- [ ] Rollback procedure: Step-by-step, copy-paste commands
- [ ] Incident response: Severity levels, response times, communication template
- [ ] Environment reference: URLs, env vars, secrets locations
- [ ] Monitoring: Dashboards, alert rules, contacts

---

## Stakeholder Package Verification

- [ ] Executive Summary: 2–3 sentences
- [ ] What Was Delivered: Bullet list with links
- [ ] Success Metrics: Baseline vs target
- [ ] Where to Find Things: Links to user docs, release notes, support
- [ ] Next Steps: Recommended follow-up

---

## Sign-Off

```
Documentation Phase 08 — COMPLETE
Signed off by: [Name]
Date: [Date]
Notes: [Any observations]
```
